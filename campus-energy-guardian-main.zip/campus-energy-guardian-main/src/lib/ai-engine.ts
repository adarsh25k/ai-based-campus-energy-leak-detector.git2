/**
 * AI Engine - Anomaly Detection, Prediction, Efficiency Grading
 * Client-side simulation of IsolationForest, LinearRegression, KMeans
 */
import { EnergyData, EfficiencyGrade, RoomAnalysis, Room, TimetableEntry, Alert } from "./types";
import { calcFullLoad, calcExpectedKw, calcWaste } from "./energy-engine";

/** Simple anomaly detection: flag if actual > 1.5x expected or < 0.3x expected when scheduled */
export function detectAnomalies(
  room: Room,
  timetable: TimetableEntry[],
  energyData: EnergyData[]
): EnergyData[] {
  return energyData.filter((d) => {
    const date = new Date(d.timestamp);
    const expected = calcExpectedKw(room, timetable, date);
    if (expected === 0) return d.actual_kw > 0.5;
    const ratio = d.actual_kw / expected;
    return ratio > 1.5 || (ratio < 0.3 && expected > 0.2);
  });
}

/** Predict next hour using simple linear trend of last 6 data points */
export function predictNextHour(energyData: EnergyData[]): number {
  if (energyData.length === 0) return 0;
  const recent = energyData.slice(-6);
  if (recent.length < 2) return recent[0]?.actual_kw ?? 0;

  // Simple linear regression on indices
  const n = recent.length;
  const xs = recent.map((_, i) => i);
  const ys = recent.map((d) => d.actual_kw);
  const sumX = xs.reduce((a, b) => a + b, 0);
  const sumY = ys.reduce((a, b) => a + b, 0);
  const sumXY = xs.reduce((a, x, i) => a + x * ys[i], 0);
  const sumXX = xs.reduce((a, x) => a + x * x, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  return Math.max(0, slope * n + intercept);
}

/** Assign efficiency grade based on average waste ratio */
export function assignGrade(avgWasteRatio: number, anomalyFreq: number): EfficiencyGrade {
  const score = avgWasteRatio * 0.7 + anomalyFreq * 0.3;
  if (score < 0.1) return "A";
  if (score < 0.3) return "B";
  if (score < 0.5) return "C";
  return "D";
}

/** Full room analysis */
export function analyzeRoom(
  room: Room,
  timetable: TimetableEntry[],
  energyData: EnergyData[]
): RoomAnalysis {
  const roomData = energyData.filter((d) => d.room_id === room.id);
  const fullLoad = calcFullLoad(room);
  const now = new Date();
  const expected = calcExpectedKw(room, timetable, now);

  const latestActual = roomData.length > 0 ? roomData[roomData.length - 1].actual_kw : 0;
  const waste = calcWaste(latestActual, expected);

  const anomalies = detectAnomalies(room, timetable, roomData);
  const anomalyFreq = roomData.length > 0 ? anomalies.length / roomData.length : 0;

  const avgWaste = roomData.length > 0
    ? roomData.reduce((sum, d) => {
        const exp = calcExpectedKw(room, timetable, new Date(d.timestamp));
        return sum + Math.max(0, d.actual_kw - exp);
      }, 0) / roomData.length
    : 0;
  const avgWasteRatio = fullLoad > 0 ? avgWaste / fullLoad : 0;

  return {
    room_id: room.id,
    full_load_kw: fullLoad,
    expected_kw: expected,
    actual_kw: latestActual,
    waste_kw: waste,
    grade: assignGrade(avgWasteRatio, anomalyFreq),
    anomaly_count: anomalies.length,
    predicted_next_hour: predictNextHour(roomData),
  };
}

/** Generate waste alerts for rooms where waste persists */
export function generateWasteAlerts(
  rooms: Room[],
  timetable: TimetableEntry[],
  energyData: EnergyData[]
): Alert[] {
  const alerts: Alert[] = [];
  for (const room of rooms) {
    const roomData = energyData.filter((d) => d.room_id === room.id);
    // Check last 10 minutes (assume ~1 reading/min)
    const recent = roomData.slice(-10);
    const wasteCount = recent.filter((d) => {
      const expected = calcExpectedKw(room, timetable, new Date(d.timestamp));
      return d.actual_kw - expected > 0.1;
    }).length;

    if (wasteCount >= 10) {
      alerts.push({
        id: `waste-${room.id}-${Date.now()}`,
        room_id: room.id,
        alert_type: "waste",
        severity: wasteCount >= 10 ? "high" : "medium",
        message: `Continuous energy waste detected in ${room.id} for >10 minutes`,
        timestamp: new Date().toISOString(),
      });
    }
  }
  return alerts;
}
