// Smart Campus Energy System - Core Types

export type RoomType = "classroom" | "lab" | "campus";

export interface Room {
  id: string;
  room_type: RoomType;
  lights: number;
  fans: number;
  ac: number;
  computers: number;
  power_per_light: number;
}

export interface TimetableEntry {
  id: string;
  room_id: string;
  day: string; // Monday, Tuesday, etc.
  start_time: string; // HH:MM
  end_time: string; // HH:MM
}

export interface EnergyData {
  id: string;
  room_id: string;
  timestamp: string; // YYYY-MM-DD HH:MM
  actual_kw: number;
}

export interface ComputerStatus {
  id: string;
  lab_id: string;
  computer_id: string;
  status: "ON" | "OFF" | "IDLE";
  last_active: string;
  timestamp: string;
}

export interface Alert {
  id: string;
  room_id: string;
  alert_type: "waste" | "ai_anomaly" | "lab" | "campus";
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  timestamp: string;
}

export type EfficiencyGrade = "A" | "B" | "C" | "D";

export interface RoomAnalysis {
  room_id: string;
  full_load_kw: number;
  expected_kw: number;
  actual_kw: number;
  waste_kw: number;
  grade: EfficiencyGrade;
  anomaly_count: number;
  predicted_next_hour: number;
}
