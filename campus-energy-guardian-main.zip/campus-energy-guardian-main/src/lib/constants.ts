// Power constants for energy calculations
// In real deployment, IoT smart energy meters would automatically provide actual_kw.

export const LIGHT_KW = 0.02;
export const FAN_KW = 0.075;
export const AC_KW = 1.5;
export const COMPUTER_KW_ACTIVE = 0.25;
export const STANDBY_KW = 0.1;
export const ELECTRICITY_COST = 8; // per kWh
export const CO2_FACTOR = 0.82; // kg CO2 per kWh

export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export const HOURS = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, "0")}:00`);
