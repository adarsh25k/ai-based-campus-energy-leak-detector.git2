/**
 * Energy Calculation Engine
 * Computes full load, expected power based on time/schedule, waste detection
 */
import { Room, TimetableEntry } from "./types";
import { LIGHT_KW, FAN_KW, AC_KW, COMPUTER_KW_ACTIVE, STANDBY_KW } from "./constants";

/** Calculate full load kW for a room */
export function calcFullLoad(room: Room): number {
  const lightPower = room.room_type === "campus" ? room.power_per_light : LIGHT_KW;
  return (
    room.lights * lightPower +
    room.fans * FAN_KW +
    room.ac * AC_KW +
    room.computers * COMPUTER_KW_ACTIVE
  );
}

/** Determine if a room is scheduled at a given time */
export function isScheduled(
  timetable: TimetableEntry[],
  roomId: string,
  date: Date
): boolean {
  const dayName = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][date.getDay()];
  const timeStr = `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;

  return timetable
    .filter((t) => t.room_id === roomId && t.day === dayName)
    .some((t) => timeStr >= t.start_time && timeStr <= t.end_time);
}

/** Check time mode */
export function getTimeMode(date: Date): "day" | "evening" | "night" {
  const h = date.getHours();
  if (h >= 17 && h < 20) return "evening";
  if (h >= 20 || h < 6) return "night";
  return "day";
}

export function isWeekend(date: Date): boolean {
  return date.getDay() === 0 || date.getDay() === 6;
}

/** Calculate expected kW at a given time */
export function calcExpectedKw(
  room: Room,
  timetable: TimetableEntry[],
  date: Date
): number {
  const fullLoad = calcFullLoad(room);
  const scheduled = isScheduled(timetable, room.id, date);
  const mode = getTimeMode(date);
  const weekend = isWeekend(date);

  if (scheduled) return fullLoad;
  if (weekend) return STANDBY_KW;
  if (mode === "evening") return 0.6 * fullLoad;
  if (mode === "night") return STANDBY_KW;
  return STANDBY_KW;
}

/** Calculate waste */
export function calcWaste(actual: number, expected: number): number {
  return Math.max(0, actual - expected);
}
