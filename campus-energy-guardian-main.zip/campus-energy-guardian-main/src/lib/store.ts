/**
 * Application State Store
 * Uses localStorage for persistence (simulating SQLite)
 */
import { Room, TimetableEntry, EnergyData, ComputerStatus, Alert } from "./types";

const KEYS = {
  rooms: "campus_rooms",
  timetable: "campus_timetable",
  energy: "campus_energy",
  computers: "campus_computers",
  alerts: "campus_alerts",
} as const;

function load<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function save<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// Rooms
export const getRooms = () => load<Room>(KEYS.rooms);
export const addRoom = (room: Room) => {
  const rooms = getRooms();
  rooms.push(room);
  save(KEYS.rooms, rooms);
};
export const getRoomById = (id: string) => getRooms().find((r) => r.id === id);

// Timetable
export const getTimetable = () => load<TimetableEntry>(KEYS.timetable);
export const addTimetableEntry = (entry: TimetableEntry) => {
  const tt = getTimetable();
  tt.push(entry);
  save(KEYS.timetable, tt);
};
export const getTimetableForRoom = (roomId: string) => getTimetable().filter((t) => t.room_id === roomId);

// Energy Data
export const getEnergyData = () => load<EnergyData>(KEYS.energy);
export const addEnergyData = (entries: EnergyData[]) => {
  const existing = getEnergyData();
  save(KEYS.energy, [...existing, ...entries]);
};
export const getEnergyForRoom = (roomId: string) => getEnergyData().filter((d) => d.room_id === roomId);

// Computer Status
export const getComputerStatus = () => load<ComputerStatus>(KEYS.computers);
export const getComputersForLab = (labId: string) => getComputerStatus().filter((c) => c.lab_id === labId);
export const updateComputerStatus = (status: ComputerStatus) => {
  const all = getComputerStatus();
  const idx = all.findIndex((c) => c.lab_id === status.lab_id && c.computer_id === status.computer_id);
  if (idx >= 0) all[idx] = status;
  else all.push(status);
  save(KEYS.computers, all);
};

// Alerts
export const getAlerts = () => load<Alert>(KEYS.alerts);
export const addAlert = (alert: Alert) => {
  const alerts = getAlerts();
  alerts.push(alert);
  save(KEYS.alerts, alerts);
};
export const addAlerts = (newAlerts: Alert[]) => {
  const alerts = getAlerts();
  save(KEYS.alerts, [...alerts, ...newAlerts]);
};
