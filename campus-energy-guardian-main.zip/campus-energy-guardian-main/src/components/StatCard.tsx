import { ReactNode } from "react";

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon: ReactNode;
  variant?: "default" | "energy" | "warning" | "critical";
}

const variantStyles = {
  default: "border-border",
  energy: "border-primary/30 glow-green",
  warning: "border-warning/30",
  critical: "border-critical/30",
};

export default function StatCard({ label, value, unit, icon, variant = "default" }: StatCardProps) {
  return (
    <div className={`gradient-card rounded-xl border p-5 ${variantStyles[variant]}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            {label}
          </p>
          <p className="stat-value text-foreground">
            {typeof value === "number" ? value.toFixed(2) : value}
            {unit && <span className="text-sm font-normal text-muted-foreground ml-1">{unit}</span>}
          </p>
        </div>
        <div className="text-muted-foreground">{icon}</div>
      </div>
    </div>
  );
}
