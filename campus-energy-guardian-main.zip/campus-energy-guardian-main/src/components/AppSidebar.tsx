import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  School,
  FlaskConical,
  Trees,
  AlertTriangle,
  PlusCircle,
  Zap,
} from "lucide-react";

const navItems = [
  { path: "/", label: "Overview", icon: LayoutDashboard },
  { path: "/add-classroom", label: "Add Classroom", icon: PlusCircle },
  { path: "/add-lab", label: "Add Lab", icon: PlusCircle },
  { path: "/add-campus", label: "Add Campus Zone", icon: PlusCircle },
  { path: "/classrooms", label: "Classrooms", icon: School },
  { path: "/labs", label: "Labs", icon: FlaskConical },
  { path: "/campus", label: "Campus Zones", icon: Trees },
  { path: "/alerts", label: "Alerts", icon: AlertTriangle },
];

export default function AppSidebar() {
  const { pathname } = useLocation();

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border bg-sidebar flex flex-col">
      {/* Logo */}
      <div className="flex items-center gap-2 px-5 py-5 border-b border-border">
        <div className="h-8 w-8 rounded-lg gradient-energy flex items-center justify-center">
          <Zap className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-bold text-sidebar-accent-foreground leading-tight">
            Smart Campus
          </h1>
          <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">
            Energy Detector
          </p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map(({ path, label, icon: Icon }) => {
          const active = pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active
                  ? "bg-primary/10 text-primary glow-green"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-border">
        <p className="text-[10px] text-muted-foreground font-mono">
          v1.0 • AI-Powered Monitoring
        </p>
      </div>
    </aside>
  );
}
