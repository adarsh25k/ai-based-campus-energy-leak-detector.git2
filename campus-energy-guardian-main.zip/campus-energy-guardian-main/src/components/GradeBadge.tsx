import { EfficiencyGrade } from "@/lib/types";

const gradeConfig: Record<EfficiencyGrade, { label: string; color: string; bg: string }> = {
  A: { label: "A - Efficient", color: "text-grade-a", bg: "bg-grade-a/10" },
  B: { label: "B - Moderate", color: "text-grade-b", bg: "bg-grade-b/10" },
  C: { label: "C - High Waste", color: "text-grade-c", bg: "bg-grade-c/10" },
  D: { label: "D - Critical", color: "text-grade-d", bg: "bg-grade-d/10" },
};

export default function GradeBadge({ grade }: { grade: EfficiencyGrade }) {
  const cfg = gradeConfig[grade];
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold font-mono ${cfg.color} ${cfg.bg}`}>
      {cfg.label}
    </span>
  );
}
