import { AlertTriangle, Zap, Monitor, Trees } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { getAlerts } from "@/lib/store";
import { Alert } from "@/lib/types";

const sectionConfig = {
  waste: { title: "Waste Alerts", icon: Zap, color: "text-accent" },
  ai_anomaly: { title: "AI Anomaly Alerts", icon: AlertTriangle, color: "text-critical" },
  lab: { title: "Lab Alerts", icon: Monitor, color: "text-info" },
  campus: { title: "Campus Alerts", icon: Trees, color: "text-primary" },
} as const;

const severityColors: Record<string, string> = {
  critical: "bg-critical/10 text-critical border-critical/30",
  high: "bg-accent/10 text-accent border-accent/30",
  medium: "bg-info/10 text-info border-info/30",
  low: "bg-muted text-muted-foreground border-border",
};

export default function AlertsPage() {
  const alerts = getAlerts();

  const grouped = {
    waste: alerts.filter((a) => a.alert_type === "waste"),
    ai_anomaly: alerts.filter((a) => a.alert_type === "ai_anomaly"),
    lab: alerts.filter((a) => a.alert_type === "lab"),
    campus: alerts.filter((a) => a.alert_type === "campus"),
  };

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold text-foreground mb-6">Alerts</h1>

      {alerts.length === 0 ? (
        <div className="gradient-card rounded-xl border border-border p-12 text-center">
          <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No alerts yet. Alerts will appear when energy anomalies are detected.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {(Object.keys(grouped) as Array<keyof typeof grouped>).map((type) => {
            const items = grouped[type];
            if (items.length === 0) return null;
            const cfg = sectionConfig[type];
            const Icon = cfg.icon;

            return (
              <div key={type}>
                <div className="flex items-center gap-2 mb-3">
                  <Icon className={`h-4 w-4 ${cfg.color}`} />
                  <h2 className="text-sm font-semibold text-foreground">{cfg.title}</h2>
                  <span className="text-xs text-muted-foreground font-mono">({items.length})</span>
                </div>
                <div className="space-y-2">
                  {items.slice().reverse().map((alert) => (
                    <div
                      key={alert.id}
                      className={`rounded-lg border px-4 py-3 flex items-center gap-3 ${severityColors[alert.severity]}`}
                    >
                      <div className="flex-1">
                        <p className="text-sm">{alert.message}</p>
                        <p className="text-xs opacity-60 mt-0.5 font-mono">
                          {alert.room_id} • {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <span className="text-xs font-bold uppercase">{alert.severity}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
