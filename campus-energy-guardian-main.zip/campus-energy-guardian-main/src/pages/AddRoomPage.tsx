import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { addRoom, addTimetableEntry } from "@/lib/store";
import { DAYS } from "@/lib/constants";
import { RoomType } from "@/lib/types";

interface Props {
  roomType: RoomType;
  title: string;
}

export default function AddRoomPage({ roomType, title }: Props) {
  const navigate = useNavigate();
  const [roomId, setRoomId] = useState("");
  const [lights, setLights] = useState(4);
  const [fans, setFans] = useState(4);
  const [ac, setAc] = useState(1);
  const [computers, setComputers] = useState(roomType === "lab" ? 30 : 0);
  const [powerPerLight, setPowerPerLight] = useState(0.02);
  const [timetableRows, setTimetableRows] = useState<{ day: string; start: string; end: string }[]>([
    { day: "Monday", start: "09:00", end: "17:00" },
  ]);

  const addTTRow = () => setTimetableRows((r) => [...r, { day: "Monday", start: "09:00", end: "17:00" }]);
  const updateTTRow = (idx: number, field: string, val: string) =>
    setTimetableRows((rows) => rows.map((r, i) => (i === idx ? { ...r, [field]: val } : r)));

  const handleSubmit = () => {
    if (!roomId.trim()) {
      toast.error("Please enter a room ID");
      return;
    }
    addRoom({
      id: roomId.trim(),
      room_type: roomType,
      lights,
      fans,
      ac,
      computers: roomType === "lab" ? computers : 0,
      power_per_light: roomType === "campus" ? powerPerLight : 0.02,
    });

    for (const row of timetableRows) {
      addTimetableEntry({
        id: `${roomId}-${row.day}-${Date.now()}-${Math.random()}`,
        room_id: roomId.trim(),
        day: row.day,
        start_time: row.start,
        end_time: row.end,
      });
    }

    toast.success(`${title} "${roomId}" added successfully`);
    navigate(roomType === "classroom" ? "/classrooms" : roomType === "lab" ? "/labs" : "/campus");
  };

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold text-foreground mb-6">{title}</h1>
      <div className="max-w-xl gradient-card rounded-xl border border-border p-6 space-y-5">
        <div>
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">
            {roomType === "campus" ? "Zone" : roomType === "lab" ? "Lab" : "Room"} ID
          </Label>
          <Input value={roomId} onChange={(e) => setRoomId(e.target.value)} placeholder={`e.g. ${roomType === "campus" ? "Zone-A" : roomType === "lab" ? "Lab-101" : "CR-201"}`} className="mt-1 bg-secondary border-border text-foreground" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Lights</Label>
            <Input type="number" value={lights} onChange={(e) => setLights(+e.target.value)} className="mt-1 bg-secondary border-border text-foreground" min={0} />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Fans</Label>
            <Input type="number" value={fans} onChange={(e) => setFans(+e.target.value)} className="mt-1 bg-secondary border-border text-foreground" min={0} />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">AC Units</Label>
            <Input type="number" value={ac} onChange={(e) => setAc(+e.target.value)} className="mt-1 bg-secondary border-border text-foreground" min={0} />
          </div>
          {roomType === "lab" && (
            <div>
              <Label className="text-muted-foreground text-xs uppercase tracking-wider">Computers</Label>
              <Input type="number" value={computers} onChange={(e) => setComputers(+e.target.value)} className="mt-1 bg-secondary border-border text-foreground" min={0} />
            </div>
          )}
          {roomType === "campus" && (
            <div>
              <Label className="text-muted-foreground text-xs uppercase tracking-wider">Power/Light (kW)</Label>
              <Input type="number" step="0.01" value={powerPerLight} onChange={(e) => setPowerPerLight(+e.target.value)} className="mt-1 bg-secondary border-border text-foreground" min={0} />
            </div>
          )}
        </div>

        {/* Timetable */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Weekly Timetable</Label>
            <Button variant="ghost" size="sm" onClick={addTTRow} className="text-primary text-xs h-7">+ Add Slot</Button>
          </div>
          <div className="space-y-2">
            {timetableRows.map((row, i) => (
              <div key={i} className="grid grid-cols-3 gap-2">
                <select
                  value={row.day}
                  onChange={(e) => updateTTRow(i, "day", e.target.value)}
                  className="rounded-md bg-secondary border border-border text-foreground text-sm px-2 py-2"
                >
                  {DAYS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
                <Input type="time" value={row.start} onChange={(e) => updateTTRow(i, "start", e.target.value)} className="bg-secondary border-border text-foreground" />
                <Input type="time" value={row.end} onChange={(e) => updateTTRow(i, "end", e.target.value)} className="bg-secondary border-border text-foreground" />
              </div>
            ))}
          </div>
        </div>

        <Button onClick={handleSubmit} className="w-full gradient-energy text-primary-foreground font-semibold">
          Add {title}
        </Button>
      </div>
    </DashboardLayout>
  );
}
