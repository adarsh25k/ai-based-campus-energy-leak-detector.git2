import { useMemo } from "react";
import { Zap, DollarSign, Cloud, AlertTriangle, TrendingUp, Activity } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import StatCard from "@/components/StatCard";
import GradeBadge from "@/components/GradeBadge";
import { getRooms, getTimetable, getEnergyData, getAlerts } from "@/lib/store";
import { analyzeRoom } from "@/lib/ai-engine";
import { ELECTRICITY_COST, CO2_FACTOR } from "@/lib/constants";

export default function OverviewPage() {
  const rooms = getRooms();
  const timetable = getTimetable();
  const energyData = getEnergyData();
  const alerts = getAlerts();

  const analyses = useMemo(
    () => rooms.map((r) => analyzeRoom(r, timetable, energyData)),
    [rooms, timetable, energyData]
  );

  const totalActual = analyses.reduce((s, a) => s + a.actual_kw, 0);
  const totalWaste = analyses.reduce((s, a) => s + a.waste_kw, 0);
  const totalCost = totalActual * ELECTRICITY_COST;
  const totalCO2 = totalActual * CO2_FACTOR;
  const anomalyCount = analyses.reduce((s, a) => s + a.anomaly_count, 0);

  const chartData = analyses.map((a) => ({
    name: a.room_id,
    actual: Number(a.actual_kw.toFixed(2)),
    expected: Number(a.expected_kw.toFixed(2)),
    waste: Number(a.waste_kw.toFixed(2)),
  }));

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Campus Overview</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Real-time energy monitoring across {rooms.length} zones
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-8">
        <StatCard label="Total Energy" value={totalActual} unit="kW" icon={<Zap className="h-5 w-5" />} variant="energy" />
        <StatCard label="Total Waste" value={totalWaste} unit="kW" icon={<TrendingUp className="h-5 w-5" />} variant={totalWaste > 1 ? "warning" : "default"} />
        <StatCard label="Cost" value={`₹${totalCost.toFixed(0)}`} icon={<DollarSign className="h-5 w-5" />} />
        <StatCard label="CO₂ Impact" value={totalCO2} unit="kg" icon={<Cloud className="h-5 w-5" />} />
        <StatCard label="AI Anomalies" value={anomalyCount} icon={<AlertTriangle className="h-5 w-5" />} variant={anomalyCount > 0 ? "critical" : "default"} />
      </div>

      {/* Chart */}
      {chartData.length > 0 ? (
        <div className="gradient-card rounded-xl border border-border p-5 mb-8">
          <h2 className="text-sm font-semibold text-foreground mb-4">Room vs Energy (kW)</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                <XAxis dataKey="name" stroke="hsl(220 10% 50%)" tick={{ fontSize: 11 }} />
                <YAxis stroke="hsl(220 10% 50%)" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(220 18% 10%)",
                    border: "1px solid hsl(220 15% 18%)",
                    borderRadius: "8px",
                    color: "hsl(160 10% 90%)",
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="expected" fill="hsl(210 80% 55%)" radius={[4, 4, 0, 0]} name="Expected" />
                <Bar dataKey="actual" fill="hsl(145 80% 42%)" radius={[4, 4, 0, 0]} name="Actual" />
                <Bar dataKey="waste" fill="hsl(45 90% 55%)" radius={[4, 4, 0, 0]} name="Waste" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      ) : (
        <div className="gradient-card rounded-xl border border-border p-12 text-center mb-8">
          <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No rooms added yet. Add classrooms, labs, or campus zones to begin monitoring.</p>
        </div>
      )}

      {/* Room table */}
      {analyses.length > 0 && (
        <div className="gradient-card rounded-xl border border-border overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Room Efficiency</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  <th className="text-left px-5 py-3 font-medium">Room</th>
                  <th className="text-right px-5 py-3 font-medium">Expected</th>
                  <th className="text-right px-5 py-3 font-medium">Actual</th>
                  <th className="text-right px-5 py-3 font-medium">Waste</th>
                  <th className="text-right px-5 py-3 font-medium">Grade</th>
                </tr>
              </thead>
              <tbody>
                {analyses.map((a) => (
                  <tr key={a.room_id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                    <td className="px-5 py-3 font-mono text-foreground">{a.room_id}</td>
                    <td className="px-5 py-3 text-right font-mono text-muted-foreground">{a.expected_kw.toFixed(2)} kW</td>
                    <td className="px-5 py-3 text-right font-mono text-foreground">{a.actual_kw.toFixed(2)} kW</td>
                    <td className="px-5 py-3 text-right font-mono text-accent">{a.waste_kw.toFixed(2)} kW</td>
                    <td className="px-5 py-3 text-right"><GradeBadge grade={a.grade} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Recent alerts */}
      {alerts.length > 0 && (
        <div className="gradient-card rounded-xl border border-border mt-8 overflow-hidden">
          <div className="px-5 py-3 border-b border-border">
            <h2 className="text-sm font-semibold text-foreground">Recent Alerts</h2>
          </div>
          <div className="divide-y divide-border/50">
            {alerts.slice(-5).reverse().map((a) => (
              <div key={a.id} className="px-5 py-3 flex items-center gap-3">
                <AlertTriangle className={`h-4 w-4 flex-shrink-0 ${a.severity === "critical" ? "text-critical" : a.severity === "high" ? "text-accent" : "text-muted-foreground"}`} />
                <span className="text-sm text-foreground flex-1">{a.message}</span>
                <span className="text-xs text-muted-foreground font-mono">{a.room_id}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
