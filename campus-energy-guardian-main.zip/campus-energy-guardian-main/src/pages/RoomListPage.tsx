import { useState, useMemo, useCallback } from "react";
import { toast } from "sonner";
import { Upload, TrendingUp } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import StatCard from "@/components/StatCard";
import GradeBadge from "@/components/GradeBadge";
import { getRooms, getTimetable, getEnergyData, addEnergyData, getComputersForLab } from "@/lib/store";
import { analyzeRoom } from "@/lib/ai-engine";
import { calcFullLoad } from "@/lib/energy-engine";
import { RoomType, EnergyData } from "@/lib/types";
import { Zap, Activity, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  roomType: RoomType;
  title: string;
}

export default function RoomListPage({ roomType, title }: Props) {
  const rooms = getRooms().filter((r) => r.room_type === roomType);
  const timetable = getTimetable();
  const energyData = getEnergyData();
  const [, setRefresh] = useState(0);

  const analyses = useMemo(
    () => rooms.map((r) => analyzeRoom(r, timetable, energyData)),
    [rooms, timetable, energyData]
  );

  // File upload handler for a specific room
  const handleFileUpload = useCallback((roomId: string, fullLoad: number) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.txt";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const text = await file.text();
      const lines = text.trim().split("\n");
      const header = lines[0].toLowerCase();

      if (!header.includes("timestamp") || !header.includes("actual_kw")) {
        toast.error("File must contain 'timestamp' and 'actual_kw' columns");
        return;
      }

      const entries: EnergyData[] = [];
      let warnings = 0;

      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(",").map((s) => s.trim());
        if (parts.length < 2) continue;
        const kw = parseFloat(parts[1]);
        if (isNaN(kw) || kw < 0) continue;
        if (kw > fullLoad * 1.5) warnings++;
        entries.push({
          id: `${roomId}-${Date.now()}-${i}`,
          room_id: roomId,
          timestamp: parts[0],
          actual_kw: kw,
        });
      }

      if (entries.length === 0) {
        toast.error("No valid data rows found");
        return;
      }

      addEnergyData(entries);
      if (warnings > 0) toast.warning(`${warnings} readings exceed 150% of full load`);
      toast.success(`Uploaded ${entries.length} readings for ${roomId}`);
      setRefresh((r) => r + 1);
    };
    input.click();
  }, []);

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold text-foreground mb-6">{title}</h1>

      {rooms.length === 0 ? (
        <div className="gradient-card rounded-xl border border-border p-12 text-center">
          <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No {roomType}s added yet.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {rooms.map((room) => {
            const analysis = analyses.find((a) => a.room_id === room.id);
            const roomEnergy = energyData.filter((d) => d.room_id === room.id);
            const fullLoad = calcFullLoad(room);
            const chartData = roomEnergy.slice(-24).map((d) => ({
              time: d.timestamp.split(" ")[1] || d.timestamp.slice(11, 16),
              actual: d.actual_kw,
            }));

            const computers = roomType === "lab" ? getComputersForLab(room.id) : [];

            return (
              <div key={room.id} className="gradient-card rounded-xl border border-border overflow-hidden">
                {/* Header */}
                <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Zap className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground font-mono">{room.id}</h3>
                      <p className="text-xs text-muted-foreground">
                        {room.lights}L • {room.fans}F • {room.ac}AC
                        {room.computers > 0 && ` • ${room.computers}PC`}
                        {" • Full Load: "}
                        <span className="text-primary font-mono">{fullLoad.toFixed(2)} kW</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {analysis && <GradeBadge grade={analysis.grade} />}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleFileUpload(room.id, fullLoad)}
                      className="border-border text-muted-foreground hover:text-foreground"
                    >
                      <Upload className="h-3.5 w-3.5 mr-1.5" /> Upload CSV
                    </Button>
                  </div>
                </div>

                {/* Stats */}
                {analysis && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5">
                    <StatCard label="Expected" value={analysis.expected_kw} unit="kW" icon={<TrendingUp className="h-4 w-4" />} />
                    <StatCard label="Actual" value={analysis.actual_kw} unit="kW" icon={<Zap className="h-4 w-4" />} variant="energy" />
                    <StatCard label="Waste" value={analysis.waste_kw} unit="kW" icon={<AlertTriangle className="h-4 w-4" />} variant={analysis.waste_kw > 0.5 ? "warning" : "default"} />
                    <StatCard label="Predicted Next Hr" value={analysis.predicted_next_hour} unit="kW" icon={<Activity className="h-4 w-4" />} />
                  </div>
                )}

                {/* Energy trend */}
                {chartData.length > 1 && (
                  <div className="px-5 pb-5">
                    <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Energy Trend</h4>
                    <div className="h-40">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                          <XAxis dataKey="time" stroke="hsl(220 10% 50%)" tick={{ fontSize: 10 }} />
                          <YAxis stroke="hsl(220 10% 50%)" tick={{ fontSize: 10 }} />
                          <Tooltip contentStyle={{ background: "hsl(220 18% 10%)", border: "1px solid hsl(220 15% 18%)", borderRadius: "8px", color: "hsl(160 10% 90%)", fontSize: 11 }} />
                          <Line type="monotone" dataKey="actual" stroke="hsl(145 80% 42%)" strokeWidth={2} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}

                {/* Lab appliance breakdown */}
                {roomType === "lab" && (
                  <div className="px-5 pb-5">
                    <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Appliance Breakdown</h4>
                    <div className="h-32">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { name: "Lights", kw: room.lights * 0.02 },
                          { name: "Fans", kw: room.fans * 0.075 },
                          { name: "AC", kw: room.ac * 1.5 },
                          { name: "PCs", kw: room.computers * 0.25 },
                        ]}>
                          <XAxis dataKey="name" stroke="hsl(220 10% 50%)" tick={{ fontSize: 10 }} />
                          <YAxis stroke="hsl(220 10% 50%)" tick={{ fontSize: 10 }} />
                          <Bar dataKey="kw" fill="hsl(145 80% 42%)" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    {/* Computer monitoring table */}
                    {computers.length > 0 && (
                      <div className="mt-4">
                        <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">Computer Status</h4>
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-border text-muted-foreground">
                                <th className="text-left px-3 py-2">PC ID</th>
                                <th className="text-left px-3 py-2">Status</th>
                                <th className="text-left px-3 py-2">Last Active</th>
                              </tr>
                            </thead>
                            <tbody>
                              {computers.map((c) => (
                                <tr key={c.computer_id} className="border-b border-border/50">
                                  <td className="px-3 py-2 font-mono text-foreground">{c.computer_id}</td>
                                  <td className="px-3 py-2">
                                    <span className={`inline-block h-2 w-2 rounded-full mr-1.5 ${c.status === "ON" ? "bg-primary" : c.status === "IDLE" ? "bg-accent" : "bg-muted-foreground"}`} />
                                    {c.status}
                                  </td>
                                  <td className="px-3 py-2 text-muted-foreground">{c.last_active}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Upload hint */}
                {/* In real deployment, IoT smart energy meters would automatically provide actual_kw. */}
                {roomEnergy.length === 0 && (
                  <div className="px-5 pb-5">
                    <p className="text-xs text-muted-foreground italic">
                      Upload a CSV file with columns: timestamp, actual_kw to see analytics.
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
