import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import OverviewPage from "./pages/OverviewPage";
import AddRoomPage from "./pages/AddRoomPage";
import RoomListPage from "./pages/RoomListPage";
import AlertsPage from "./pages/AlertsPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<OverviewPage />} />
          <Route path="/add-classroom" element={<AddRoomPage roomType="classroom" title="Add Classroom" />} />
          <Route path="/add-lab" element={<AddRoomPage roomType="lab" title="Add Lab" />} />
          <Route path="/add-campus" element={<AddRoomPage roomType="campus" title="Add Campus Zone" />} />
          <Route path="/classrooms" element={<RoomListPage roomType="classroom" title="Classrooms" />} />
          <Route path="/labs" element={<RoomListPage roomType="lab" title="Labs" />} />
          <Route path="/campus" element={<RoomListPage roomType="campus" title="Campus Zones" />} />
          <Route path="/alerts" element={<AlertsPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
